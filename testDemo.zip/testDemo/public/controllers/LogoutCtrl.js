myApp.controller("LogoutCtrl", function($location,localStorageService){
	window.localStorage['storageName'] = "";
	$location.path("/");
});