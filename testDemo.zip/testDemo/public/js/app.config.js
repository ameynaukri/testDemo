/**
*	Define all global configuration
***/
myApp.run(['$rootScope', function($rootScope){
    $rootScope.serviceURL = 'http://localhost:3016/';
    //$rootScope.imageURL = 'http://192.168.1.112:2017/uploads/';
}]);

