require('./dist/ng-file-upload-all');
module.exports = 'ngFileUpload';