myApp.config(function($routeProvider){
	$routeProvider.when("/",{
		templateUrl:"templates/login.html",
        controller:"loginCtrl"
	})
    $routeProvider.when("/allUsers",{
        templateUrl:"templates/allUsers.html",
        controller:"allUsersCtrl"
    })
    $routeProvider.when("/edit",{
        templateUrl:"templates/edit.html",
    })
    $routeProvider.when("/AddReg",{
        templateUrl:"templates/AddReg.html",
        controller:"AddRegCtrl"  
    })
});

